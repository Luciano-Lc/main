module.exports ={
    plugins: ["prettier-plugins-tailwindcss"]
}
