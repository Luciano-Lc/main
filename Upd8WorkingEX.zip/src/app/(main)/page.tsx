import BookTable from "./book/BookTable";

export default function Home() {
  return (
    <div>
      <BookTable books={[]} />
    </div>
  );
}
